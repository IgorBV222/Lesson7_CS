﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Inventory001
{
    public partial class Form1 : Form
    {
        Action<object> output;
        public Form1()
        {
            InitializeComponent();
            string test_query = "CREATE TABLE  IF NOT EXISTS EqNode(id INTEGER PRIMARY KEY AUTOINCREMENT, 'SwitchName' NVARCHAR );" +
                " INSERT INTO EqNode(SwitchName) VALUES ('SW-TEST');" +
                " INSERT INTO EqNode(SwitchName) VALUES ('SW-TEST');" +
                " INSERT INTO EqNode(SwitchName) VALUES ('SW-TEST');" +
                " SELECT * FROM EqNode;";
            output = getOutput;
            SQLiteIO test = new SQLiteIO("test002.db", output, test_query);
        }
        private void getOutput(object _text)
        {
            label1.Text = _text.ToString();
        }
    }
}
