﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Inventory001
{
    internal class SQLiteIO
    {
        public SQLiteIO(string _DBName, 
            Action<object> output=null, 
            string _command= "select 'Успешно';")
        {
            string _source = "Data Source=" + _DBName + ";";
            string _cache = "Cache=Shared;";
            string _mode = "Mode=ReadWriteCreate;";
            SQLiteConnection myConnection = new SQLiteConnection(_source + _cache + _mode);
            SQLiteCommand myQuery = new SQLiteCommand(_command, myConnection);
            myConnection.Open();
            var dr = myQuery.ExecuteReader();
            string result = string.Empty;
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    var ans01 = dr.GetValue(0);
                    var ans02 = dr.GetValue(1);

                    result += ans01.ToString() + " \t " + ans02.ToString() + "\n";
                }
            }
            MessageBox.Show(result);
            output?.Invoke(result);
        }
        
    }
}
